#!/bin/bash
sudo apt-get update
sudo apt-get install python
sudo apt-get install sysbench
sudo apt-get install ioping
sudo apt-get install hdparm
sudo apt-get install speedtest-cli
sudo apt-get install bonnie++
sudo apt-get install stress-ng
